### Hexlet tests and linter status:
[![Actions Status](https://github.com/vodoo13/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/vodoo13/python-project-49/actions)
<a href="https://codeclimate.com/github/vodoo13/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d0e2c19f3bb3dab4096f/maintainability" /></a>
https://asciinema.org/a/iaSt7G5NXIFlVZPPwq5XBiUQf
https://asciinema.org/a/O6Lro5U8cATWXE8Cv2JQTNhJD
